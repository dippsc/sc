//Ubah disini bro
//SUBSCRIBE YT : Xello Crash
global.baileys1 = require('@whiskeysockets/baileys') 
global.prefa = ['','!','.',',','⚡','🤡']
global.nocreator = ['6285876593597']
global.owner = ['6285876593597']
global.botname = 'DippSoloUser'
global.sticker1 = "sticker"
global.sticker2 = "dipp"